// Interface para el mensaje de login

export interface ISwal {
    title: string,
    text: string,
    icon: string,
    button: string,
}