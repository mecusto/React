export interface IBook {
    book_code: number;
    title: string;
    first_name: string;
    last_name: string;
    year_written: number;
    price:number;
  }
