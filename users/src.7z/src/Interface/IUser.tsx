export interface IUser {
    id_users: number;
    username: string;
    email: string;
    isAdmin: boolean;
  }

